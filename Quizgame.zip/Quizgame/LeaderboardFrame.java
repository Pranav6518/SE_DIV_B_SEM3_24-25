import java.awt.*;
import java.util.List;
import java.util.Map;
import javax.swing.*;

public class LeaderboardFrame extends JFrame {
    private LeaderboardManager leaderboardManager;

    public LeaderboardFrame() {
        leaderboardManager = new LeaderboardManager();

        setTitle("Leaderboard");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Leaderboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 22));
        add(titleLabel, BorderLayout.NORTH);

        // Create a text area to show the leaderboard
        JTextArea leaderboardArea = new JTextArea();
        leaderboardArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        leaderboardArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(leaderboardArea);
        add(scrollPane, BorderLayout.CENTER);

        // Load top scores and display them
        List<Map.Entry<Integer, String>> topScores = leaderboardManager.getTopScores(10); // Get top 10
        StringBuilder leaderboardText = new StringBuilder();
        leaderboardText.append(String.format("%-20s %s%n", "Player", "Score"));
        leaderboardText.append("--------------------------------\n");

        for (Map.Entry<Integer, String> entry : topScores) {
            leaderboardText.append(String.format("%-20s %d%n", entry.getValue(), entry.getKey()));
        }

        leaderboardArea.setText(leaderboardText.toString());

        setVisible(true);
    }
}

