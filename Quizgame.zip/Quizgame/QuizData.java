// QuizData.java
import java.util.List;

public class QuizData {
    private List<Question> questions;

    public QuizData(List<Question> questions) {
        this.questions = questions;
    }

    public List<Question> getQuestions() {
        return questions;
    }
}
