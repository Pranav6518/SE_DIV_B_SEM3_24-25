
// QuizSelectionFrame.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class QuizSelectionFrame extends JFrame {

        private JButton[] quizButtons;
        private String[] quizTopics = {
                        "Operating System",
                        "Database Management Systems",
                        "Data Structures and Algorithms",
                        "Computer Graphics"
        };

        // Map to hold quiz data
        private HashMap<String, QuizData> quizzes;

        public QuizSelectionFrame() {
                setTitle("Select a Quiz Topic");
                setSize(700, 500);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                setLocationRelativeTo(null); // Center the frame

                // Initialize quiz data
                initializeQuizzes();

                // Create UI components
                JPanel panel = new JPanel(new GridBagLayout());
                panel.setBackground(new Color(52, 73, 94)); // Dark blue-gray background
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.insets = new Insets(15, 15, 15, 15); // Padding

                // Welcome Label
                JLabel welcomeLabel = new JLabel("Select a Quiz Topic");
                welcomeLabel.setFont(new Font("Verdana", Font.BOLD, 24));
                welcomeLabel.setForeground(Color.WHITE);
                gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.gridwidth = 2;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(welcomeLabel, gbc);

                // Quiz Buttons
                for (int i = 0; i < quizTopics.length; i++) {
                        JButton button = new JButton(quizTopics[i]);
                        button.setFont(new Font("Tahoma", Font.BOLD, 18));
                        button.setBackground(new Color(0, 162, 232)); // Light blue color
                        button.setForeground(Color.WHITE);
                        button.setFocusPainted(false);
                        button.setPreferredSize(new Dimension(250, 60));

                        gbc.gridx = i % 2;
                        gbc.gridy = (i / 2) + 1;
                        gbc.gridwidth = 1;
                        panel.add(button, gbc);

                        // Add Action Listener to each quiz button
                        button.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                        String selectedQuiz = button.getText();
                                        new QuizGamess(selectedQuiz, quizzes.get(selectedQuiz));
                                        dispose(); // Close the selection frame
                                }
                        });
                }

                add(panel);
                setVisible(true);
        }

        // Method to initialize quizzes with subtopics
        private void initializeQuizzes() {
                quizzes = new HashMap<>();

                // Operating System Quiz
                List<Question> osQuestions = new ArrayList<>();
                osQuestions.add(new Question(
                                "What is the primary function of an operating system?",
                                new String[] { "To manage hardware resources", "To create application software",
                                                "To design computer networks", "To develop databases" },
                                0,
                                "Resource Management"));
                osQuestions.add(new Question(
                                "Which of the following is NOT a type of operating system?",
                                new String[] { "Batch OS", "Real-Time OS", "Network OS", "Database OS" },
                                3,
                                "OS Types"));
                osQuestions.add(new Question(
                                "What component of the OS manages memory allocation?",
                                new String[] { "File Manager", "Processor Scheduler", "Memory Manager",
                                                "Device Manager" },
                                2,
                                "Memory Management"));
                osQuestions.add(new Question(
                                "Which OS is known for its strong security features and is widely used in servers?",
                                new String[] { "Windows", "Linux", "macOS", "Android" },
                                1,
                                "Security"));
                osQuestions.add(new Question(
                                "What is the term for running multiple processes simultaneously on a CPU?",
                                new String[] { "Multithreading", "Multiprocessing", "Multitasking", "Multiversioning" },
                                2,
                                "Process Management"));

                quizzes.put("Operating System", new QuizData(osQuestions));

                // Database Management Systems Quiz
                List<Question> dbmsQuestions = new ArrayList<>();
                dbmsQuestions.add(new Question(
                                "What does SQL stand for?",
                                new String[] { "Structured Query Language", "Simple Query Language",
                                                "Sequential Query Language", "Standard Query Language" },
                                0,
                                "SQL Basics"));
                dbmsQuestions.add(new Question(
                                "Which of the following is a NoSQL database?",
                                new String[] { "MySQL", "PostgreSQL", "MongoDB", "Oracle" },
                                2,
                                "Database Types"));
                dbmsQuestions.add(new Question(
                                "What is the primary key in a database table?",
                                new String[] { "A unique identifier for each record",
                                                "A field that can have NULL values", "A foreign key from another table",
                                                "A non-unique field" },
                                0,
                                "Keys and Constraints"));
                dbmsQuestions.add(new Question(
                                "Which normal form eliminates transitive dependencies?",
                                new String[] { "First Normal Form", "Second Normal Form", "Third Normal Form",
                                                "Boyce-Codd Normal Form" },
                                2,
                                "Normalization"));
                dbmsQuestions.add(new Question(
                                "What is a JOIN operation used for in SQL?",
                                new String[] { "To combine rows from two or more tables", "To delete rows from a table",
                                                "To update rows in a table", "To create a new table" },
                                0,
                                "SQL Operations"));

                quizzes.put("Database Management Systems", new QuizData(dbmsQuestions));

                // Data Structures and Algorithms Quiz
                List<Question> dsaQuestions = new ArrayList<>();
                dsaQuestions.add(new Question(
                                "What data structure uses LIFO (Last In, First Out) principle?",
                                new String[] { "Queue", "Stack", "Tree", "Graph" },
                                1,
                                "Data Structures"));
                dsaQuestions.add(new Question(
                                "What is the time complexity of binary search in the average case?",
                                new String[] { "O(n)", "O(n log n)", "O(log n)", "O(1)" },
                                2,
                                "Algorithm Complexity"));
                dsaQuestions.add(new Question(
                                "Which sorting algorithm has the best worst-case time complexity?",
                                new String[] { "Quick Sort", "Merge Sort", "Heap Sort", "Bubble Sort" },
                                1,
                                "Sorting Algorithms"));
                dsaQuestions.add(new Question(
                                "What is the main advantage of a linked list over an array?",
                                new String[] { "Random access", "Dynamic size", "Better cache performance",
                                                "Less memory usage" },
                                1,
                                "Data Structures"));
                dsaQuestions.add(new Question(
                                "In a graph, what is a path that starts and ends at the same vertex called?",
                                new String[] { "Path", "Cycle", "Trail", "Circuit" },
                                1,
                                "Graph Theory"));

                quizzes.put("Data Structures and Algorithms", new QuizData(dsaQuestions));

                // Computer Graphics Quiz
                List<Question> cgQuestions = new ArrayList<>();
                cgQuestions.add(new Question(
                                "What does GPU stand for?",
                                new String[] { "Graphics Processing Unit", "General Processing Unit",
                                                "Graphical Performance Unit", "Graphics Performance Utility" },
                                0,
                                "Hardware Components"));
                cgQuestions.add(new Question(
                                "Which of the following is a vector graphics editor?",
                                new String[] { "Adobe Photoshop", "Adobe Illustrator", "Corel Painter", "GIMP" },
                                1,
                                "Graphics Software"));
                cgQuestions.add(new Question(
                                "What is the term for the set of rules that describe how to display a 3D object on a 2D screen?",
                                new String[] { "Rasterization", "Modeling", "Projection", "Shading" },
                                2,
                                "Rendering Techniques"));
                cgQuestions.add(new Question(
                                "Which shading technique calculates lighting for each pixel?",
                                new String[] { "Flat Shading", "Gouraud Shading", "Phong Shading",
                                                "Wireframe Shading" },
                                2,
                                "Shading Techniques"));
                cgQuestions.add(new Question(
                                "What is the primary file format used for 3D models in many applications?",
                                new String[] { "JPEG", "OBJ", "PNG", "SVG" },
                                1,
                                "File Formats"));

                quizzes.put("Computer Graphics", new QuizData(cgQuestions));
        }
}
