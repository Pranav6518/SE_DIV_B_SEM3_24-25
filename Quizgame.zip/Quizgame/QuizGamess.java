// QuizGamess.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap; // Import HashMap
import java.util.List; // Import List

public class QuizGamess extends JFrame implements ActionListener { // Implement ActionListener

    private JLabel questionLabel, timerLabel;
    private JRadioButton[] optionButtons;
    private JButton nextButton;
    private int currentQuestionIndex;
    private int score;
    private Timer timer;
    private int timeRemaining;
    private final int TIME_LIMIT = 15; // Time limit per question (in seconds)

    private List<Question> questions; // Use List instead of java.util.List
    private List<String> correctAnswers;
    private List<String> incorrectSubtopics; // To track subtopics of incorrect answers

    public QuizGamess(String quizTitle, QuizData quizData) {
        this.questions = quizData.getQuestions();
        this.correctAnswers = new ArrayList<>();
        this.incorrectSubtopics = new ArrayList<>();

        setTitle("Quiz Game - " + quizTitle);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Main panel with BorderLayout for responsiveness
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(44, 62, 80)); // Dark blue background

        // Subpanel for Timer and Question Labels using GridBagLayout
        JPanel headerPanel = new JPanel(new GridBagLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.setBackground(new Color(44, 62, 80)); // Match main panel

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding

        // Timer label
        timerLabel = new JLabel("Time Remaining: " + TIME_LIMIT + " seconds");
        timerLabel.setFont(new Font("Verdana", Font.BOLD, 18));
        timerLabel.setForeground(new Color(231, 76, 60)); // Red color
        timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        headerPanel.add(timerLabel, gbc);

        // Question label
        questionLabel = new JLabel();
        questionLabel.setFont(new Font("Verdana", Font.BOLD, 22));
        questionLabel.setForeground(Color.WHITE);
        questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        questionLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0; // Allow horizontal expansion
        headerPanel.add(questionLabel, gbc);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Options panel
        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(4, 1, 15, 15)); // Added gaps between options
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));
        optionsPanel.setBackground(new Color(44, 62, 80)); // Match main panel

        optionButtons = new JRadioButton[4];
        ButtonGroup buttonGroup = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setFont(new Font("Tahoma", Font.PLAIN, 18));
            optionButtons[i].setBackground(new Color(44, 62, 80)); // Match main panel
            optionButtons[i].setForeground(Color.WHITE); // White text
            optionButtons[i].setFocusPainted(false);
            optionButtons[i].setOpaque(true);
            optionButtons[i].setBorder(BorderFactory.createLineBorder(new Color(0, 162, 232), 2));
            optionsPanel.add(optionButtons[i]);
            buttonGroup.add(optionButtons[i]);
        }

        mainPanel.add(optionsPanel, BorderLayout.CENTER);

        // Next button
        nextButton = new JButton("Next");
        nextButton.setFont(new Font("Tahoma", Font.BOLD, 18));
        nextButton.setBackground(new Color(0, 162, 232)); // Light blue color
        nextButton.setForeground(Color.WHITE);
        nextButton.setFocusPainted(false);
        nextButton.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        nextButton.setPreferredSize(new Dimension(150, 50));
        nextButton.addActionListener(this); // Use this for ActionListener

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80)); // Match main panel
        buttonPanel.add(nextButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        // Initialize game state
        currentQuestionIndex = 0;
        score = 0;
        showNextQuestion();

        setVisible(true);
    }

    private void showNextQuestion() {
        if (currentQuestionIndex < questions.size()) {
            Question question = questions.get(currentQuestionIndex);
            questionLabel.setText("<html><body style='text-align: center;'>" + question.getQuestionText() + "</body></html>");
            String[] options = question.getOptions();
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i].setText(options[i]);
                optionButtons[i].setSelected(false);
            }

            // Start the timer for this question
            timeRemaining = TIME_LIMIT;
            updateTimerLabel();
            if (timer != null) {
                timer.stop();
            }
            timer = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    timeRemaining--;
                    updateTimerLabel();
                    if (timeRemaining <= 0) {
                        timer.stop();
                        JOptionPane.showMessageDialog(QuizGamess.this, "Time's up for this question!", "Time Up", JOptionPane.WARNING_MESSAGE);
                        incorrectSubtopics.add(question.getSubtopic()); // No selection implies wrong answer
                        currentQuestionIndex++;
                        showNextQuestion();
                    }
                }
            });
            timer.start();
        } else {
            // No more questions; show final score and feedback
            showFinalFeedback();
        }
    }

    private void updateTimerLabel() {
        timerLabel.setText("Time Remaining: " + timeRemaining + " seconds");
    }

    private void checkAnswer() {
        if (currentQuestionIndex >= questions.size()) {
            return; // No action if quiz is already finished
        }

        Question question = questions.get(currentQuestionIndex);
        int selectedOptionIndex = -1;
        for (int i = 0; i < optionButtons.length; i++) {
            if (optionButtons[i].isSelected()) {
                selectedOptionIndex = i;
                break;
            }
        }

        if (selectedOptionIndex == question.getCorrectAnswerIndex()) {
            score++;
            // Optional: Provide immediate feedback
            JOptionPane.showMessageDialog(this, "Correct!", "Good Job", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Optional: Provide immediate feedback
            String correctAnswer = question.getOptions()[question.getCorrectAnswerIndex()];
            JOptionPane.showMessageDialog(this, "Incorrect! The correct answer was: " + correctAnswer, "Oops!", JOptionPane.ERROR_MESSAGE);
            incorrectSubtopics.add(question.getSubtopic());
        }
        currentQuestionIndex++;
    }

    private void showFinalFeedback() {
        // Calculate feedback based on incorrectSubtopics
        if (incorrectSubtopics.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Excellent! You answered all questions correctly.", "Quiz Finished", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Aggregate subtopics
            HashMap<String, Integer> subtopicCount = new HashMap<>();
            for (String subtopic : incorrectSubtopics) {
                subtopicCount.put(subtopic, subtopicCount.getOrDefault(subtopic, 0) + 1);
            }

            // Build feedback message
            StringBuilder feedback = new StringBuilder("<html>Your Performance:<br><br>");
            feedback.append("Total Score: ").append(score).append(" out of ").append(questions.size()).append("<br><br>");
            feedback.append("Areas for Improvement:<br>");
            for (String subtopic : subtopicCount.keySet()) {
                feedback.append("- ").append(subtopic).append(" (Missed ")
                        .append(subtopicCount.get(subtopic)).append(" questions)<br>");
            }
            feedback.append("</html>");

            // Show feedback in a JOptionPane
            JOptionPane.showMessageDialog(this, feedback.toString(), "Quiz Finished", JOptionPane.INFORMATION_MESSAGE);
        }

        // Redirect to Quiz Selection
        new QuizSelectionFrame(); // Open the quiz selection frame
        this.dispose(); // Close the quiz frame
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextButton) {
            // Stop the timer when user clicks Next
            if (timer != null && timer.isRunning()) {
                timer.stop();
            }
            checkAnswer();
            showNextQuestion();
        }
    }
}
