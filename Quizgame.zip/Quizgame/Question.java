// Question.java
public class Question {
    private String questionText;
    private String[] options;
    private int correctAnswerIndex;
    private String subtopic;

    public Question(String questionText, String[] options, int correctAnswerIndex, String subtopic) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
        this.subtopic = subtopic;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public int getCorrectAnswerIndex() {
        return correctAnswerIndex;
    }

    public String getSubtopic() {
        return subtopic;
    }
}

