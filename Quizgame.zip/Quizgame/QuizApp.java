// QuizApp.java
import javax.swing.SwingUtilities;

public class QuizApp {
    public static void main(String[] args) {
        // Launch the Login Frame on the Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame();
            }
        });
    }
}

