import java.io.*;
import java.util.*;

public class LeaderboardManager {
    private static final String LEADERBOARD_FILE = "leaderboard.txt";
    private TreeMap<Integer, String> leaderboard; // Scores sorted by score in descending order

    public LeaderboardManager() {
        leaderboard = new TreeMap<>(Collections.reverseOrder());
        loadLeaderboard();
    }

    // Load leaderboard from file
    private void loadLeaderboard() {
        try (BufferedReader reader = new BufferedReader(new FileReader(LEADERBOARD_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String user = parts[0];
                    int score = Integer.parseInt(parts[1]);
                    leaderboard.put(score, user);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading leaderboard: " + e.getMessage());
        }
    }

    // Save leaderboard to file
    private void saveLeaderboard() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LEADERBOARD_FILE))) {
            for (Map.Entry<Integer, String> entry : leaderboard.entrySet()) {
                writer.write(entry.getValue() + "," + entry.getKey());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving leaderboard: " + e.getMessage());
        }
    }

    // Add a new score to the leaderboard
    public void addScore(String user, int score) {
        leaderboard.put(score, user);
        saveLeaderboard();
    }

    // Get top N scores
    public List<Map.Entry<Integer, String>> getTopScores(int n) {
        List<Map.Entry<Integer, String>> topScores = new ArrayList<>(leaderboard.entrySet());
        return topScores.subList(0, Math.min(n, topScores.size()));
    }
}

