// FeedbackFrame.java
import java.awt.*;
import java.util.HashMap;
import javax.swing.*;

public class FeedbackFrame extends JFrame {

    public FeedbackFrame(int score, int total, HashMap<String, Integer> subtopicCount) {
        setTitle("Quiz Feedback");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame
        setLayout(new BorderLayout());

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(44, 62, 80)); // Dark blue background
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Label
        JLabel titleLabel = new JLabel("Your Quiz Performance");
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Feedback Area
        JTextArea feedbackArea = new JTextArea();
        feedbackArea.setEditable(false);
        feedbackArea.setFont(new Font("Tahoma", Font.PLAIN, 16));
        feedbackArea.setForeground(Color.WHITE);
        feedbackArea.setBackground(new Color(44, 62, 80));
        feedbackArea.setLineWrap(true);
        feedbackArea.setWrapStyleWord(true);

        // Building the feedback message
        StringBuilder feedback = new StringBuilder();
        feedback.append("Total Score: ").append(score).append(" out of ").append(total).append("\n\n");

        if (subtopicCount.isEmpty()) {
            feedback.append("Excellent! You answered all questions correctly.");
        } else {
            feedback.append("Areas for Improvement:\n");
            for (String subtopic : subtopicCount.keySet()) {
                feedback.append("- ").append(subtopic).append(": Missed ")
                        .append(subtopicCount.get(subtopic)).append(" question(s)\n");
            }
        }

        feedbackArea.setText(feedback.toString());

        // Scroll Pane for Feedback
        JScrollPane scrollPane = new JScrollPane(feedbackArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Close Button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        closeButton.setBackground(new Color(0, 162, 232)); // Light blue color
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setPreferredSize(new Dimension(100, 40));
        closeButton.addActionListener(e -> dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80));
        buttonPanel.add(closeButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
        setVisible(true);
    }
}

